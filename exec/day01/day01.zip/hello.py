#!/usr/bin/env python
# 从终端输入接收一个用户名，然后打印欢迎该用户

name = input('Please Entry UserName:')      # 变量赋值的过程
print('Welcome', name)
print('Welcome' + name)
print('Welcome', name, sep='T0T')
