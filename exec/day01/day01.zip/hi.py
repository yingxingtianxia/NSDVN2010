#!/usr/bin/env python

#print()语句
"""
print('Hello World')                    #打印
print('Hello', 'World')                 #，连接中间有空格
print('Hello'+'World')                  #+连接中间没有空格
print('Hello World' * 3)                #打印多个
print('Hello', 'World', sep='====')     #设置连接符号
print('Hello', 'World', end='我是李老六')         #修改换行符
"""
#vim编辑器设置
# vim ~/.vimrc
# set nu
# set ai
# set ts=4
# set et


#input()
input('提示信息')

# >>> 1 < 3 and 5 > 3       True and True  -> True
# True
# >>> 1 < 3 and 5 < 3       True and False  -> False
# False
# >>> 1 < 3 or 5 > 3        True or True  -> True
# True
# >>> 1 < 3 or 5 < 3        True or False -> True
# True
# >>> 1 > 3 and 5 < 3       false and false -> False
# False
# >>> 1 > 3 or 5 < 3        false or false -> false
# False
#
# >>> 1 > 0
# True
# >>> not 1 > 0     #取反
# False
#
# >>> 'a' in 'abc'
# True
# >>> 'a' not in 'abc'
# False
# >>>

